# Experimento VQE — análise do parâmetro θ₁₇

Este diretório reúne os principais gráficos do experimento em que o parâmetro **θ₁₇ foi fixado** em diferentes posições de uma grade angular, enquanto os demais parâmetros do ansatz foram reotimizados.

## Configuração resumida

- Parâmetro analisado: `theta_index = 17`
- Bloco original do ansatz: `CCY`
- Tipo físico primitivo: `RY`
- Qubits lógicos do bloco: `(3, 4, 5)`
- Período angular usado: `2π`
- Pontos da grade angular: `7`
- Otimizador: `COBYLA`
- Avaliações máximas por reinicialização: `250`
- Distribuição observada: `4096 shots`
- Referência exata: `Statevector`

---

## 1. Gap energético após reotimização

![Gap energético com θ₁₇ fixado](theta17_gap_apos_reotimizacao.png)

### Leitura do resultado

O gap energético obtido com **θ₁₇ fixado no intervalo identificado como ótimo** permanece muito abaixo da mediana do baseline com todos os parâmetros livres.

A curva do controle deslocado por `T/2` praticamente coincide com a curva do intervalo ótimo. Isso indica que, após a reotimização dos demais parâmetros, o circuito consegue compensar amplamente o deslocamento aplicado a θ₁₇. Portanto, neste teste, o gap final não separa claramente as duas condições.

---

## 2. Probabilidade da solução ótima

![Probabilidade exata e com 4096 shots](theta17_probabilidade_exata_4096shots.png)

### Leitura do resultado

A probabilidade da solução ótima permanece elevada em toda a grade, aproximadamente entre `0.96` e `0.995`.

As estimativas com `4096 shots` acompanham de perto os valores exatos do Statevector, mostrando que o erro amostral é pequeno para esta análise.

O melhor desempenho ocorre nas posições centrais da grade, enquanto as extremidades apresentam uma redução moderada em `P(x*)`. Mesmo assim, todas as posições testadas permanecem acima do baseline livre mostrado no gráfico.

---

## Conclusão provisória

Os resultados sustentam três observações:

1. Fixar θ₁₇ na região analisada não impede que o restante do circuito recupere uma solução de alta qualidade.
2. O deslocamento de `T/2` não produz uma degradação clara depois que os demais parâmetros são reotimizados.
3. θ₁₇ pode ser importante para a trajetória de otimização, mas o seu valor final não parece ser rigidamente identificável de forma isolada neste experimento.

Assim, este teste não demonstra que existe um único valor indispensável para θ₁₇. Ele sugere uma possível **redundância paramétrica ou compensação pelos demais ângulos do ansatz**.

---

## Arquivos

- `theta17_gap_apos_reotimizacao.png`
- `theta17_probabilidade_exata_4096shots.png`
